package com.example.testplan;

public class student {
    String id;
    String name;
    String course;
    String fee;
    String titles;

}