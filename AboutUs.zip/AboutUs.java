package com.example.testplan;

import android.os.Bundle;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;

public class AboutUs extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us); // Ensure this matches your XML file name

        // Initialize the WebView and load the local HTML file
        WebView webViewer = findViewById(R.id.bt5);
        webViewer.loadUrl("file:///android_asset/www/index.html");
    }
}
