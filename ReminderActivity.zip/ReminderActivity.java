package com.example.testplan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;
import com.example.testplan.R;

import androidx.appcompat.app.AppCompatActivity;


public class ReminderActivity extends AppCompatActivity {

    TimePicker timePicker;
    EditText noteEditText;
    Button setReminderButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);

        timePicker = findViewById(R.id.timePicker);
        noteEditText = findViewById(R.id.noteEditText);
        setReminderButton = findViewById(R.id.setReminderButton);

        setReminderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get reminder time from TimePicker
                int hour = timePicker.getCurrentHour();
                int minute = timePicker.getCurrentMinute();

                // Get notes from EditText
                String notes = noteEditText.getText().toString();

                // Implement logic to set reminder (e.g., using AlarmManager)
                // Example: scheduleReminder(hour, minute, notes);

                Toast.makeText(ReminderActivity.this, "Reminder set for " + hour + ":" + minute, Toast.LENGTH_LONG).show();

                // Optionally, save reminder details to database or preferences
                // saveReminderToDatabase(hour, minute, notes);

                // Finish activity and return to MainActivity or wherever needed
                finish();
            }
        });
    }
}
